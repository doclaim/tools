# coding:utf-8
import redis
import yaml
import sys
import os
import time
import commands
import types

class Plugin(object):
    name = ''
    description = ''
    version = ''
    redisobj = ''
    pubcn = ''
    resdic = {}

    @classmethod
    def connmaster(cls,json):
        #a, b = commands.getstatusoutput('echo "' + json + '" >> /tmp/test')
        print type(Plugin.redisobj)
        if type(Plugin.redisobj) is types.StringType:
            common_yaml = yaml.load(open('/usr/local/ras/etc/common.yaml'))
            common = common_yaml['root']['setting']
            srvip = common['srvip']
            srvport = common['srvport']
            Plugin.pubch = common['pubch']
            Plugin.redisobj = redis.Redis(srvip, srvport)
        Plugin.redisobj.publish(Plugin.pubch,json)

    def __init__(self):
        pass

    def executeFun(self):
        pass

    def push(self,key,value):
        #resdic=Plugin.resdic
        #if resdic.has_key(key) == False:
        #    resdic[key]=value
        #else:
        #    if resdic[key] == value:
        #        return
        json='%s' %value
        Plugin.connmaster(json)
        #
        

    def log(self,objname,content):
    	log = objname + ' | ' + content + ' | ' + time.strftime('%Y-%m-%d %H:%M:%S')
    	a, b = commands.getstatusoutput('echo "' + log + '">>/usr/local/ras/logs/agent.log')
    	print a

