# coding:utf-8
import sys
import time
import psutil
import platform
sys.path.append('../')

from iPlugin import Plugin
import commands
__all__ = ["configPlugin"]


class configPlugin(Plugin):
    name = "configPlugin"
    interval = 3

    def __init__(self):
        Plugin.__init__(self)

    def execute(self):
        a,b = commands.getstatusoutput("sh /usr/local/ras/bin/sh/getip_mac_status.sh")
        json='{"id":"01248785xx","hostname":true,"serialno":"2124111411144",\
        "cpunum":2,"cpumodel":"E520","memnum":2,"memsize":"8G","memtype":"DDR3",\
        "' + b + '}'
        Plugin.push(self,"config",json)
        #try:
        #    Plugin.push(self,"parent call")
        #except Exception, e:
        #    #commands.getstatusoutput(" echo '" + e + "' >> /tmp/test")