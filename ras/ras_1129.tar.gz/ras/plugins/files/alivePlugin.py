# coding:utf-8
import sys
import time
sys.path.append('../')

from iPlugin import Plugin
import commands
__all__ = ["alivePlugin"]


class alivePlugin(Plugin):
    name = "alivePlugin"
    interval = 3

    def __init__(self):
        Plugin.__init__(self)

    def execute(self):
        a ,b = commands.getstatusoutput("date '+%F %T'")
        Plugin.push(self,"alive",b)
        #try:
        #    Plugin.push(self,"parent call")
        #except Exception, e:
        #    #commands.getstatusoutput(" echo '" + e + "' >> /tmp/test")