# coding:utf-8


class Plugin(object):
    name = ''
    description = ''
    version = ''

    def __init__(self):
        pass

    def executeFun(self):
        pass
