# coding:utf-8
import sys
import os
import time
import commands

class Plugin(object):
    name = ''
    description = ''
    version = ''

    def __init__(self):
        pass

    def executeFun(self):
        pass

    def log(self,objname,content):
    	log = objname + ' | ' + content + ' | ' + time.strftime('%Y-%m-%d %H:%M:%S')
    	a, b = commands.getstatusoutput('echo "' + log + '">>/usr/local/ras/logs/agent.log')
    	print a

